package com.example.lims.paymentManagement;

public class Sample {
}
