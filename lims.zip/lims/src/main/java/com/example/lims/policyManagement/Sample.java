package com.example.lims.policyManagement;

public class Sample {
}
