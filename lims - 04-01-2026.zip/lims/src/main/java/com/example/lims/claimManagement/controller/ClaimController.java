package com.example.lims.claimManagement.controller;

import com.example.lims.claimManagement.bean.Claim;
import com.example.lims.claimManagement.service.ClaimService;
import com.example.lims.user.bean.User;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping("/claims")
public class ClaimController {

    @Autowired
    private ClaimService claimService;

    // 🔐 Common ADMIN check
    private boolean isAdmin(HttpSession session) {
        User user = (User) session.getAttribute("user");
        return user != null && "ADMIN".equalsIgnoreCase(user.getRole());
    }

    @GetMapping("/home")
    public ModelAndView showClaimsHome(HttpSession session) {

        // 1️⃣ Not logged in
        if (session.getAttribute("user") == null) {
            return new ModelAndView("redirect:/auth/login");
        }

        // 2️⃣ Not ADMIN
        if (!isAdmin(session)) {
            return new ModelAndView("no-access");
        }

        // 3️⃣ Authorized
        ModelAndView mav = new ModelAndView("claims-home");
        mav.addObject("claims", claimService.getAllClaims());
        mav.addObject("newClaim", new Claim());
        return mav;
    }

    @PostMapping("/add")
    public String addClaim(
            @ModelAttribute("newClaim") Claim claim,
            HttpSession session) {

        if (!isAdmin(session)) {
            return "no-access";
        }

        claimService.submitClaim(claim);
        return "redirect:/claims/home";
    }

    @GetMapping("/view/{id}")
    public ModelAndView getClaimDetails(
            @PathVariable int id,
            HttpSession session) {

        if (session.getAttribute("user") == null) {
            return new ModelAndView("redirect:/auth/login");
        }

        if (!isAdmin(session)) {
            return new ModelAndView("no-access");
        }

        ModelAndView mav = new ModelAndView("claim-details");
        Claim claim = claimService.getClaimDetails(id);
        mav.addObject("claim", claim);
        return mav;
    }
}
