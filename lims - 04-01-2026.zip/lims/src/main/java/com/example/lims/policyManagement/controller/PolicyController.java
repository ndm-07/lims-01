package com.example.lims.policyManagement.controller;

import com.example.lims.policyManagement.bean.Policy;
import com.example.lims.policyManagement.service.PolicyService;
import com.example.lims.user.bean.User;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import java.util.List;
import java.util.Optional;

@Controller
@RequestMapping("/policy")
public class PolicyController {

    @Autowired
    private PolicyService policyService;

    // 🔐 Common role checks
    private boolean isLoggedIn(HttpSession session) {
        return session.getAttribute("user") != null;
    }

    private boolean isAdmin(HttpSession session) {
        User user = (User) session.getAttribute("user");
        return user != null && "ADMIN".equalsIgnoreCase(user.getRole());
    }

    // ---------------- HOME ----------------
    @GetMapping("/home")
    public String showPolicyHome(HttpSession session) {
        if (!isLoggedIn(session)) {
            return "redirect:/auth/login";
        }
        return "policy-home";
    }

    // ---------------- ADD POLICY (ADMIN) ----------------
    @GetMapping("/add")
    public String showAddPolicyForm(Model model, HttpSession session) {
        if (!isAdmin(session)) {
            return "no-access";
        }
        model.addAttribute("policy", new Policy());
        return "policy-add";
    }

    @PostMapping("/save")
    public String savePolicy(@ModelAttribute("policy") Policy policy,
                             HttpSession session) {
        if (!isAdmin(session)) {
            return "no-access";
        }
        policyService.savePolicy(policy);
        return "redirect:/policy/all";
    }

    // ---------------- VIEW POLICIES ----------------
    @GetMapping("/all")
    public ModelAndView getAllPolicies(HttpSession session) {

        if (!isLoggedIn(session)) {
            return new ModelAndView("redirect:/auth/login");
        }

        List<Policy> list = policyService.getAllPolicies();
        ModelAndView mav = new ModelAndView("policy-list");
        mav.addObject("policies", list);
        return mav;
    }

    @GetMapping("/view-by-number")
    public ModelAndView viewPolicyByNumber(
            @RequestParam("policyNumber") String policyNumber,
            HttpSession session) {

        if (!isLoggedIn(session)) {
            return new ModelAndView("redirect:/auth/login");
        }

        ModelAndView mav = new ModelAndView("policy-details");
        Optional<Policy> policy = policyService.getPolicyByNumber(policyNumber);

        if (policy.isPresent()) {
            mav.addObject("policy", policy.get());
        } else {
            mav.setViewName("policy-home");
            mav.addObject("error", "Policy " + policyNumber + " not found!");
        }
        return mav;
    }

    // ---------------- UPDATE POLICY (ADMIN) ----------------
    @GetMapping("/updateform")
    public ModelAndView showUpdateList(HttpSession session) {

        if (!isAdmin(session)) {
            return new ModelAndView("no-access");
        }

        List<Policy> list = policyService.getAllPolicies();
        ModelAndView mav = new ModelAndView("policy-update-form");
        mav.addObject("policies", list);
        return mav;
    }

    @GetMapping("/edit/{num}")
    public ModelAndView showEditForm(@PathVariable("num") String num,
                                     HttpSession session) {

        if (!isAdmin(session)) {
            return new ModelAndView("no-access");
        }

        ModelAndView mav = new ModelAndView("policy-update");
        Optional<Policy> policy = policyService.getPolicyByNumber(num);

        policy.ifPresentOrElse(
                p -> mav.addObject("policy", p),
                () -> mav.setViewName("redirect:/policy/updateform")
        );
        return mav;
    }

    @PostMapping("/update")
    public String updatePolicy(@ModelAttribute("policy") Policy policy,
                               HttpSession session) {

        if (!isAdmin(session)) {
            return "no-access";
        }

        policyService.savePolicy(policy);
        return "redirect:/policy/home";
    }

    // ---------------- DELETE POLICY (ADMIN) ----------------
    @PostMapping("/execute-delete")
    public String executeDelete(@RequestParam("policyNumber") String policyNumber,
                                HttpSession session) {

        if (!isAdmin(session)) {
            return "no-access";
        }

        boolean isDeleted = policyService.deleteByPolicyNumber(policyNumber);
        return isDeleted
                ? "redirect:/policy/all"
                : "redirect:/policy/home?error=PolicyNotFound";
    }
}
