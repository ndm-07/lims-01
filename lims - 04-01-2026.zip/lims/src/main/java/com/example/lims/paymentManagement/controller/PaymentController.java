package com.example.lims.paymentManagement.controller;

import com.example.lims.paymentManagement.bean.Payment;
import com.example.lims.paymentManagement.service.PaymentService;
import com.example.lims.policyManagement.service.PolicyService;
import com.example.lims.user.bean.User;
import jakarta.servlet.http.HttpSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/payment")
public class PaymentController {

    private static final Logger logger =
            LoggerFactory.getLogger(PaymentController.class);

    private final PaymentService paymentService;
    private final PolicyService policyService;

    public PaymentController(PaymentService paymentService, PolicyService policyService) {
        this.paymentService = paymentService;
        this.policyService = policyService;
    }

    @GetMapping("/home")
    public String home(Model model, HttpSession session) {

        logger.info("Accessing payment home page");

        User user = (User) session.getAttribute("user");

        if (user == null) {
            logger.warn("Unauthorized access attempt to payment page");
            return "redirect:/auth/login";
        }

        if (!"ADMIN".equalsIgnoreCase(user.getRole())) {
            logger.warn("Access denied for user {} with role {}",
                    user.getUsername(), user.getRole());
            return "no-access";
        }

        logger.info("Admin {} accessed payment module", user.getUsername());

        model.addAttribute("payments", paymentService.getAllPayments());
        model.addAttribute("policies", policyService.getAllPolicies());
        model.addAttribute("newPayment", new Payment());

        return "payment-home";
    }

    @PostMapping("/makePayment")
    public String makePayment(
            @RequestParam int policyId,
            @ModelAttribute("newPayment") Payment payment,
            Model model) {

        logger.info("Initiating payment for policyId {}", policyId);

        try {
            paymentService.makePayment(policyId, payment);
            logger.info("Payment successful for policyId {}", policyId);
            return "redirect:/payment/home";
        } catch (Exception e) {
            logger.error("Payment failed for policyId {} : {}",
                    policyId, e.getMessage());

            model.addAttribute("errorMessage", e.getMessage());
            model.addAttribute("payments", paymentService.getAllPayments());
            model.addAttribute("policies", policyService.getAllPolicies());
            return "payment-home";
        }
    }
}
