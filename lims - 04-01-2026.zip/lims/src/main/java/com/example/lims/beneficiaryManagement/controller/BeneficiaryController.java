package com.example.lims.beneficiaryManagement.controller;

import com.example.lims.beneficiaryManagement.bean.Beneficiary;
import com.example.lims.beneficiaryManagement.service.BeneficiaryService;
import com.example.lims.user.bean.User;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping("/beneficiary")
public class BeneficiaryController {

    @Autowired
    private BeneficiaryService beneficiaryService;

    // 🔐 Common access check
    private boolean isAdmin(HttpSession session) {
        User user = (User) session.getAttribute("user");
        return user != null && "ADMIN".equalsIgnoreCase(user.getRole());
    }

    @GetMapping("/home")
    public ModelAndView showBeneficiaryPage(HttpSession session) {

        // 1️⃣ Not logged in
        if (session.getAttribute("user") == null) {
            return new ModelAndView("redirect:/auth/login");
        }

        // 2️⃣ Not ADMIN
        if (!isAdmin(session)) {
            return new ModelAndView("no-access");
        }

        // 3️⃣ Authorized
        ModelAndView mav = new ModelAndView("beneficiary-home");
        mav.addObject("beneficiaries", beneficiaryService.listAll());
        mav.addObject("newBeneficiary", new Beneficiary());
        return mav;
    }

    @PostMapping("/add")
    public String addBeneficiary(
            @ModelAttribute("newBeneficiary") Beneficiary beneficiary,
            HttpSession session) {

        if (!isAdmin(session)) {
            return "no-access";
        }

        beneficiaryService.save(beneficiary);
        return "redirect:/beneficiary/home";
    }

    @GetMapping("/delete/{id}")
    public String deleteBeneficiary(
            @PathVariable("id") int id,
            HttpSession session) {

        if (!isAdmin(session)) {
            return "no-access";
        }

        beneficiaryService.remove(id);
        return "redirect:/beneficiary/home";
    }
}
