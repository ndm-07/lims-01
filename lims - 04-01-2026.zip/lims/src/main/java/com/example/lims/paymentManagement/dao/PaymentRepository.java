package com.example.lims.paymentManagement.dao;

import com.example.lims.paymentManagement.bean.Payment;
import org.springframework.data.repository.CrudRepository;

import java.time.LocalDate;
import java.util.List;

public interface PaymentRepository extends CrudRepository<Payment, Integer> {

    List<Payment> findByPolicy_PolicyId(int policyId);

    boolean existsByPolicy_PolicyIdAndPaymentDateBetween(
            int policyId, LocalDate start, LocalDate end);
}
