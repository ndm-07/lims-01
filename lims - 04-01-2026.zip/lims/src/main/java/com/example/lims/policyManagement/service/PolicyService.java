package com.example.lims.policyManagement.service;

import com.example.lims.policyManagement.bean.Policy;
import com.example.lims.policyManagement.dao.PolicyRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class PolicyService {

    @Autowired
    private PolicyRepository policyRepository;

    public void savePolicy(Policy policy) {
        policyRepository.save(policy);
    }

    public List<Policy> getAllPolicies() {
        return (List<Policy>) policyRepository.findAll();
    }

    public Optional<Policy> getPolicyByNumber(String policyNumber) {
        return policyRepository.findByPolicyNumber(policyNumber);
    }

    public void deletePolicy(Integer id) {
        policyRepository.deleteById(id);
    }

    public Optional<Policy> getPolicyById(Integer id) {
        return policyRepository.findById(id);
    }

    public boolean deleteByPolicyNumber(String policyNumber) {
        Optional<Policy> policyOpt = policyRepository.findByPolicyNumber(policyNumber);
        if (policyOpt.isPresent()) {
            policyRepository.delete(policyOpt.get());
            return true;
        }
        return false;
    }
}
