package com.example.lims.paymentManagement.service;

import com.example.lims.paymentManagement.bean.Payment;
import com.example.lims.paymentManagement.dao.PaymentRepository;
import com.example.lims.policyManagement.bean.Policy;
import com.example.lims.policyManagement.service.PolicyService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.time.LocalDate;

@Service
public class PaymentService {

    private static final Logger logger =
            LoggerFactory.getLogger(PaymentService.class);

    private final PaymentRepository repo;
    private final PolicyService policyService;

    public PaymentService(PaymentRepository repo, PolicyService policyService) {
        this.repo = repo;
        this.policyService = policyService;
    }

    public Iterable<Payment> getAllPayments() {
        logger.debug("Fetching all payments");
        return repo.findAll();
    }

    public void makePayment(int policyId, Payment payment) throws Exception {

        logger.debug("Processing payment for policyId {}", policyId);

        Policy policy = policyService.getPolicyById(policyId)
                .orElseThrow(() -> {
                    logger.error("Policy not found: {}", policyId);
                    return new Exception("Policy does not exist");
                });

        if (!"ACTIVE".equalsIgnoreCase(policy.getPolicyStatus())) {
            logger.warn("Payment attempted on non-active policy {}", policyId);
            throw new Exception("Payment allowed only for ACTIVE policies");
        }

        LocalDate today = LocalDate.now();

        if (repo.existsByPolicy_PolicyIdAndPaymentDateBetween(
                policyId,
                today.withDayOfMonth(1),
                today.withDayOfMonth(today.lengthOfMonth()))) {

            logger.warn("Duplicate payment attempt for policy {} this month", policyId);
            throw new Exception("Premium already paid for this month");
        }

        payment.setPolicy(policy);
        payment.setPaymentDate(today);
        payment.setPaymentAmount(policy.getPremiumAmount().doubleValue());
        payment.setPaymentStatus("SUCCESS");

        repo.save(payment);

        logger.info("Payment saved successfully for policy {}", policyId);
    }
}
